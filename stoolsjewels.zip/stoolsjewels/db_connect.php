<?php
// Database connection parameters
$host = 'localhost'; // Your server, usually 'localhost'
$username = 'root'; // MySQL username
$password = ''; // MySQL password (empty by default in XAMPP)
$dbname = 'museum'; // Name of your database

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
